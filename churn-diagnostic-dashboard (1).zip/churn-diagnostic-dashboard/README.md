# Customer Churn Diagnostic & Prediction Dashboard

An interactive Streamlit app diagnosing why a subscription-style business is losing
customers, and training four classification models to test how predictable churn is
from customer attributes.

## What's inside

| Tab | Objective |
|-----|-----------|
| 1️⃣ Descriptive | Cross-tabulations of every categorical field against `Churn`, with counts, row-%, per-group churn charts. |
| 2️⃣ Diagnostic | χ² tests + Cramér's V to rank which factors drive churn; deep dives by tenure band and support call volume. |
| 3️⃣ Feature Engineering | The full cleaning + encoding pipeline, documented and reproducible. |
| 4️⃣ Models | Logistic Regression, Decision Tree, Random Forest, Gradient Boosting + metric table. |
| 5️⃣ Evaluation | ROC curves, metric comparison, confusion matrices, feature importance. |
| 📋 Findings | Written business-strategy diagnosis, caveats, and recommended next steps. |

## Data

`customer_churn_raw.csv` (bundled sample, 512 rows incl. deliberate duplicates, before
cleaning). Target = `Churn` (`Yes` / `No`). You can also upload your own CSV with the
same schema from the sidebar.

Expected columns: `CustomerID, Gender, SeniorCitizen, Tenure, Contract, PaymentMethod,
InternetService, TechSupport, OnlineSecurity, PaperlessBilling, MonthlyCharges,
TotalCharges, SupportCalls, Churn`.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

Then open the URL it prints (default http://localhost:8501).

## Deploy free on Streamlit Community Cloud

1. Create a GitHub repo and push `app.py`, `requirements.txt`,
   `customer_churn_raw.csv`, `README.md` (repo root).
2. Go to https://share.streamlit.io, sign in with GitHub.
3. New app → pick your repo, branch `main`, main file `app.py` → Deploy.

## Method notes (for auditability)

- **Duplicate rows removed** by comparing all columns except `CustomerID`, then by
  `CustomerID` itself.
- **Text variants normalised** (e.g. `month-to-month ` / `Month-to-month` →
  `Month-to-month`).
- **Impossible values treated as missing** — negative `Tenure`.
- **Outliers corrected** — `MonthlyCharges` beyond 3×IQR above Q3 set to missing, then
  imputed.
- **Missing values:** numeric columns median-imputed, categorical columns filled with
  the most frequent category.
- **Encoding:** numerics standardised; categoricals one-hot encoded with
  `handle_unknown='ignore'`.
- **Leakage caution:** `Churn`/`CHURNED` and `CustomerID` are excluded from the model's
  input features, which keeps reported accuracy/AUC realistic instead of inflated.

All numbers recompute live from the loaded data; nothing in the app is hard-coded.
